import EMF.coches;
import fsg.in;
class Aplicaci�n
{
   public static void main(String[] args)
   {
      coches c=new coches(in.leerString("Introduzca la Matr�cula: ",v->v.matches("[0-9]{4}[A-Z]+")),coches.Combustible.valueOf(in.leerString("Introduce el tipo de Combustible",v->v.equals("gasoil")||v.equals("gasolina95")||v.equals("gasolina98"))),in.leerInt("Introduzca los Litros: ",v->v>=0));
      System.out.println("El coche puede Recorrer esta distancia: "+c.distancia()+"km");
      c.repostar((int)(Math.random()*21));
      System.out.println("El coche ahora puede Recorrer esta distancia: "+c.distancia()+"km");
   }