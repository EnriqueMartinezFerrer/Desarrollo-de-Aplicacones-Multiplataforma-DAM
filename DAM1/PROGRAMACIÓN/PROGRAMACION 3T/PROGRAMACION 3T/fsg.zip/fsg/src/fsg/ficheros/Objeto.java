package fsg.ficheros;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Objeto<T> {
	public final String FICHERO;
	private ObjectInputStream lector;
	
	public Objeto(String fichero) throws IOException
	{
		FICHERO = Ruta.directorio(fichero);
		
		if(!new File(FICHERO).isFile())
			new ObjectOutputStream(new FileOutputStream(FICHERO)).close();
		
		lector = new ObjectInputStream (new FileInputStream(FICHERO));
	}
	
	public void abrir() throws IOException
	{
		lector.close();
		lector = new ObjectInputStream (new FileInputStream(FICHERO));	
	}
	
	public void cerrar() throws IOException
	{
		lector.close();
	}
	
	public void vaciar() throws IOException
	{
		lector.close();
		new ObjectOutputStream(new FileOutputStream(FICHERO)).close();
	}
	
	public void eliminar() throws IOException
	{
		lector.close();
		new File(FICHERO).delete();
	}
	
	@SuppressWarnings("unchecked")
	public T leer() throws IOException, ClassNotFoundException
	{
		T o = null;
		try
		{
			o = (T) lector.readObject();
		}
		catch(EOFException e)
		{
	
		}
		return o;
	}
	
	public void escribir(T o) throws IOException
	{
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FICHERO,true))
		{
			@Override
			protected void writeStreamHeader()
			{
					       
			}
		};
		oos.writeObject(o);
		oos.close();
	}
}
