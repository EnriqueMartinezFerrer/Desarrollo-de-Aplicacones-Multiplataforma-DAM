package fsg.ficheros;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.UnsupportedEncodingException;

public class UnObjeto<T> {
	public final String FICHERO;
	private T vacio;
	
	public UnObjeto(String fichero, T vacio) throws UnsupportedEncodingException {
		if(vacio==null)
			throw new IllegalArgumentException("El objeto no puede ser nulo");
		
		this.vacio = vacio;
                FICHERO = Ruta.directorio(fichero);
	}
	
	@SuppressWarnings("unchecked")
	public T leer() throws ClassNotFoundException, IOException
	{
		T valor;
		
		if(!(new File(FICHERO).isFile()))	 
		{
			ObjectOutputStream fs = new ObjectOutputStream(new FileOutputStream(FICHERO));
			fs.writeObject(vacio);
			fs.close();
		}
					
		ObjectInputStream fe = new ObjectInputStream(new FileInputStream(FICHERO));
		valor = (T) fe.readObject();
		fe.close();

		return valor;
	}
	
	public void escribir(T t) throws FileNotFoundException, IOException
	{
		if(t==null)
			throw new IllegalArgumentException("El objeto no puede ser nulo");
		
		ObjectOutputStream fs=new ObjectOutputStream(new FileOutputStream(FICHERO));
		fs.writeObject(t);
		fs.close();
	}

}
