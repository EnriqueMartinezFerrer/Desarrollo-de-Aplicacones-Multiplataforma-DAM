package fsg.ficheros;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Data {
    public final String FICHERO;
    private DataInputStream lector;
    private final Class<?>[] clases;
	
    public Data(String fichero, Class<?> ... clases) throws IOException {
        if(clases==null || clases.length==0)
            throw new IllegalArgumentException("No hay clases");
        for(Class v:clases)
            if(v!=Byte.class &&
               v!=Short.class &&
               v!=Integer.class &&
               v!=Long.class &&
               v!=Float.class &&
               v!=Double.class &&
               v!=Boolean.class &&
               v!=Character.class &&
               v!=String.class)
                throw new IllegalArgumentException("Tipo de datos incorrecto");
        //for(int c:clases);
            
        FICHERO = Ruta.directorio(fichero);
        if(!new File(FICHERO).isFile())
                new DataOutputStream(new FileOutputStream (FICHERO)).close();
        lector= new DataInputStream(new FileInputStream(FICHERO));
        this.clases = clases;
    }

    public void abrir() throws IOException {
        lector.close();
        lector= new DataInputStream(new FileInputStream(FICHERO));	
    }

    public void cerrar() throws IOException {
        lector.close();
    }

    public void vaciar() throws IOException {
        lector.close();
        new DataOutputStream(new FileOutputStream (FICHERO)).close();
    }

    public void eliminar() throws IOException {
        lector.close();
        new File(FICHERO).delete();
    }

    public Object[] leer() throws IOException, ClassNotFoundException {
        Object[] datos = new Object[clases.length];
        for(int i=0;i<clases.length;i++)
            {
                try
                {
                    if(clases[i]==Byte.class) datos[i] = lector.readByte();
                    else if(clases[i]==Short.class) datos[i] = lector.readShort();
                    else if(clases[i]==Integer.class) datos[i] = lector.readInt();
                    else if(clases[i]==Long.class) datos[i] = lector.readLong();
                    else if(clases[i]==Float.class) datos[i] = lector.readFloat();
                    else if(clases[i]==Double.class) datos[i] = lector.readDouble();
                    else if(clases[i]==Boolean.class) datos[i] = lector.readBoolean();
                    else if(clases[i]==Character.class) datos[i] = lector.readChar();
                    else datos[i] = lector.readUTF();
                }
                catch(Exception e)
                {
                    return null;
                }
            }
        
        return datos;
    }

    public void escribir(Object ... datos) throws IOException {
        if(datos==null || datos.length!=clases.length)
            throw new IllegalArgumentException("Numero insificiente de datos");
        for(int i=0;i<datos.length;i++)
            if(datos[i]==null || datos[i].getClass()!=clases[i])
                throw new IllegalArgumentException("Tipo incorrecto de dato");
        
        DataOutputStream escritor = new DataOutputStream(new FileOutputStream (FICHERO,true));
        for(int i=0;i<datos.length;i++)
            if(clases[i]==Byte.class) escritor.writeByte((Byte)(datos[i]));
            else if(clases[i]==Short.class) escritor.writeShort((Short)datos[i]);
            else if(clases[i]==Integer.class) escritor.writeInt((Integer)datos[i]);
            else if(clases[i]==Long.class) escritor.writeLong((Long)datos[i]);
            else if(clases[i]==Float.class) escritor.writeFloat((Float)datos[i]);
            else if(clases[i]==Double.class) escritor.writeDouble((Double)datos[i]);
            else if(clases[i]==Boolean.class) escritor.writeBoolean((Boolean)datos[i]);
            else if(clases[i]==Character.class) escritor.writeChar((Character)datos[i]);
            else if(clases[i]==String.class) escritor.writeUTF((String)datos[i]);
        escritor.close();	
    }
}
