package fsg.ficheros;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;

public class Ruta {
    final public static String JAR;
    final public static String PATH;
    final public static String RAIZ;

    static
    {
        JAR = Ruta.class.getProtectionDomain().getCodeSource().getLocation().getFile();
        PATH = JAR.substring(0,JAR.lastIndexOf('/'));
        RAIZ = JAR.substring(0,JAR.indexOf('/',1));
    }
    
    public static String directorio(String fichero) throws UnsupportedEncodingException
    {
        String ruta = PATH+"/"+fichero;
        if(fichero.indexOf("/")==0) ruta = fichero;
        fichero = URLDecoder.decode(ruta,"UTF-8");

        /* CREAR DIRECTORIO Y FICHERO SI NO EXISTE */
        String inverso = new StringBuffer(fichero).reverse().toString();
        int a = inverso.indexOf("/");
        inverso = new StringBuffer(inverso.substring(a)).reverse().toString();
        new File(inverso).mkdirs();
        
        return fichero;
            //f.createNewFile();
    }
    
    public static String fichero(String fichero) throws IOException
    {
        fichero = directorio(fichero);
        new File(fichero).createNewFile();
        return fichero;
    }
}
