package fsg.ficheros;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Buffered {
    
    public final String FICHERO;
    private BufferedReader lector;
    private final int[] tam;
    private final Class<?>[] clases;
	
    public Buffered(String fichero, Object ... dat) throws IOException {
        if(dat==null || dat.length==0 || dat.length%2==1)
            throw new IllegalArgumentException("No hay tamaños o numero insuficiente");
        
        int n = dat.length/2;
        tam = new int[n];
        clases = new Class[n];
        
        for(int i=0;i<dat.length;i++)
            if(i%2==0) clases[i/2]=(Class<?>) dat[i];
            else tam[(i-1)/2]=(int)dat[i];            
        
        for(int v:tam)
            if(v<=0)
                throw new IllegalArgumentException("Tamaño incorrecto: "+ v);
        
        for(Class v:clases)
            if(v!=Byte.class &&
               v!=Short.class &&
               v!=Integer.class &&
               v!=Long.class &&
               v!=Float.class &&
               v!=Double.class &&
               v!=Boolean.class &&
               v!=Character.class &&
               v!=String.class)
                    throw new IllegalArgumentException("Tipo de datos incorrecto");
        
        FICHERO = Ruta.directorio(fichero);
        if(!new File(FICHERO).isFile())
            new BufferedWriter(new FileWriter(FICHERO)).close();
        
        lector = new BufferedReader(new FileReader(FICHERO));
    }

    
    public void abrir() throws IOException {
        lector.close();
        lector = new BufferedReader(new FileReader(FICHERO));	
    }

    public void cerrar() throws IOException {
        lector.close();
    }

    public void vaciar() throws IOException {
        lector.close();
        new BufferedWriter(new FileWriter(FICHERO)).close();
    }

    public Object[] leer() throws IOException, ClassNotFoundException {
        Object[] datos = new Object[tam.length];
        
        if(!lector.ready()) return null;
        
        String linea = lector.readLine();
        for(int i=0;i<tam.length;i++)
        {
            String dato = linea.substring(0, tam[i]).trim();
            if(dato.equals("")) datos[i]=null;
            else if(clases[i]==Byte.class) datos[i] = Byte.valueOf(dato);
            else if(clases[i]==Short.class) datos[i] = Short.valueOf(dato);
            else if(clases[i]==Integer.class) datos[i] = Integer.valueOf(dato);
            else if(clases[i]==Long.class) datos[i] = Long.valueOf(dato);
            else if(clases[i]==Float.class) datos[i] = Float.valueOf(dato);
            else if(clases[i]==Double.class) datos[i] = Double.valueOf(dato);
            else if(clases[i]==Boolean.class) datos[i] = Boolean.valueOf(dato);
            else if(clases[i]==Character.class) datos[i] = dato.charAt(0);
            else if(clases[i]==String.class) datos[i] = dato;
            
            linea = linea.substring(tam[i]);
        }
        
        return datos;
    }

    public void escribir(Object ... datos) throws IOException {
        if(datos==null || datos.length!=tam.length)
            throw new IllegalArgumentException("Numero insificiente de datos");
        for(int i=0;i<datos.length;i++)
            if(datos[i]!=null &&
               !(datos[i] instanceof Byte) &&
               !(datos[i] instanceof Short) &&
               !(datos[i] instanceof Integer) &&
               !(datos[i] instanceof Long) &&
               !(datos[i] instanceof Float) &&
               !(datos[i] instanceof Double) &&
               !(datos[i] instanceof Character) && 
               !(datos[i] instanceof Boolean)&& 
               !(datos[i] instanceof String))
                throw new IllegalArgumentException("Tipo incorrecto de dato");
        
        String linea = "";
        for(int i=0;i<datos.length;i++)
        {
            String parte = "";
            if(datos[i]==null)
            {
                for(int j=0;j<tam[i];j++)
                    parte+=" ";
            }
            else
            {
                parte = datos[i].toString();
                if(parte.length()>tam[i])
                    parte = parte.substring(0,tam[i]);
                int lon = parte.length();
                for(int j=0;j<tam[i]-lon;j++)
                    parte+=" ";
            }
            linea+=parte;
        }
        
        BufferedWriter ecritor = new BufferedWriter(new FileWriter(FICHERO,true));
        ecritor.write(linea);
        ecritor.newLine();
        ecritor.close();
    }
    
    public void eliminar() throws IOException {
        lector.close();
        new File(FICHERO).delete();
    }
}
