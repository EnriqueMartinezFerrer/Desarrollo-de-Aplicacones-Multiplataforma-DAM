package fsg.bd;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Properties;

public class Bd {
   
    final public static String JAR;
    final public static String PATH;
    final public static String RAIZ;

    static
    {
        JAR = Bd.class.getProtectionDomain().getCodeSource().getLocation().getFile();
        PATH = JAR.substring(0,JAR.lastIndexOf('/'));
        RAIZ = JAR.substring(0,JAR.indexOf('/',1));
    }
    
    final public String SERVIDOR;
    final public String BASE;
    final public String USUARIO;
    final public String PASSWORD;

    public Bd(String fichero)
    {
        Properties propiedades = null;
        
        String ruta = PATH+"/"+fichero;
        if(fichero.indexOf("/")==0) ruta = fichero;
        
        propiedades = new Properties();
        try {
            propiedades.load(new FileReader(URLDecoder.decode(ruta,"UTF-8")));
        } catch (UnsupportedEncodingException ex) {
            java.util.logging.Logger.getLogger(Bd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            java.util.logging.Logger.getLogger(Bd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IOException ex) {
            java.util.logging.Logger.getLogger(Bd.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        
        SERVIDOR = propiedades.getProperty("host");
        BASE = propiedades.getProperty("bd");
        USUARIO = propiedades.getProperty("user");
        PASSWORD = propiedades.getProperty("password");
    }
  
    private Connection con = null;
    private PreparedStatement pre = null;
    private Object[] valores;
    private Class<?>[] clases;
    private Class<?>[] salida;

    private void prepararComando(String sql,Class<?>[] salida,Object ... dat) throws SQLException
    {
        if(salida!=null && salida.length==0)
            throw new IllegalArgumentException("No hay salida");

        if(salida!=null) for(Class v:salida)
             if(v!=Byte.class &&
                v!=Short.class &&
                v!=Integer.class &&
                v!=Long.class &&
                v!=Float.class &&
                v!=Double.class &&
                v!=Boolean.class &&
                v!=Character.class &&
                v!=String.class)
                     throw new IllegalArgumentException("Tipo de datos de salida incorrecto");

        if(salida==null)this.salida = null;
        else this.salida = salida.clone();

        if(dat.length!=0 && dat.length%2==1)
             throw new IllegalArgumentException("Error en el numero de parametos");

        int n = dat.length/2;
        valores = new Object[n];
        clases = new Class[n];

        for(int i=0;i<dat.length;i++)
             if(i%2==0) clases[i/2]=(Class<?>) dat[i];
             else valores[(i-1)/2]=dat[i];  

        for(Class v:clases)
             if(v!=Byte.class &&
                v!=Short.class &&
                v!=Integer.class &&
                v!=Long.class &&
                v!=Float.class &&
                v!=Double.class &&
                v!=Boolean.class &&
                v!=Character.class &&
                v!=String.class)
                     throw new IllegalArgumentException("Tipo de datos incorrecto");

        
        for(int i=0;i<valores.length;i++)
            if(valores[i]!=null && !(valores[i].getClass().equals(clases[i])))
                 throw new IllegalArgumentException("Tipo de valor incorrecto");
        
        pre = con.prepareStatement(sql);

        for(int i=0;i<valores.length;i++)
            if(valores[i]==null) pre.setString(i+1, null);
            else if(clases[i]==Byte.class) pre.setByte(i+1, (byte) valores[i]);
            else if(clases[i]==Short.class) pre.setShort(i+1, (short) valores[i]);
            else if(clases[i]==Integer.class) pre.setInt(i+1, (int) valores[i]);
            else if(clases[i]==Long.class) pre.setLong(i+1, (long) valores[i]);
            else if(clases[i]==Float.class) pre.setFloat(i+1, (float) valores[i]);
            else if(clases[i]==Double.class) pre.setDouble(i+1, (double) valores[i]);
            else if(clases[i]==Boolean.class) pre.setBoolean(i+1, (boolean) valores[i]);
            else if(clases[i]==Character.class) pre.setString(i+1, (String) valores[i]);
            else if(clases[i]==String.class) pre.setString(i+1, (String) valores[i]);
    }

    public int executeUpdate(String sql, Object ... datos) throws SQLException
    {
        con = DriverManager.getConnection(SERVIDOR+BASE,USUARIO,PASSWORD);
        this.prepararComando(sql, null, datos);

        int n = pre.executeUpdate();
        pre.close();
        con.close();

        return n;
    }

    public int executeUpdateServidor(String sql, Object ... datos) throws SQLException
    {
        con = DriverManager.getConnection(SERVIDOR,USUARIO,PASSWORD);
        this.prepararComando(sql, null, datos);

        int n = pre.executeUpdate();
        pre.close();
        con.close();

        return n;
    }

    public ArrayList<ArrayList> executeQuery(String sql,Class<?>[] salida, Object ... datos) throws SQLException
    {
        ArrayList<ArrayList> sal = new ArrayList<ArrayList>();

        con = DriverManager.getConnection(SERVIDOR+BASE,USUARIO,PASSWORD);
        this.prepararComando(sql, salida, datos);

        ResultSet r = pre.executeQuery();
        while(r.next())
        {
             ArrayList<Object> fila = new ArrayList<Object>();

             for(int i=0;i<salida.length;i++)
                 if(r.getString(i+1)==null) fila.add(null);
                 else if(salida[i]==Byte.class) fila.add(r.getByte(i+1));
                 else if(salida[i]==Short.class) fila.add(r.getShort(i+1));
                 else if(salida[i]==Integer.class) fila.add(r.getInt(i+1));
                 else if(salida[i]==Long.class) fila.add(r.getLong(i+1));
                 else if(salida[i]==Float.class) fila.add(r.getFloat(i+1));
                 else if(salida[i]==Double.class) fila.add(r.getDouble(i+1));
                 else if(salida[i]==Boolean.class) fila.add(r.getBoolean(i+1));
                 else if(salida[i]==Character.class) fila.add(r.getString(i+1));
                 else if(salida[i]==String.class) fila.add(r.getString(i+1));
             sal.add(fila);
        }

        r.close();
        pre.close();
        con.close();

        return sal;
    }
    
    public boolean executeExists(String sql,Object ... datos) throws SQLException
    {
        boolean hayFilas;
        
        con = DriverManager.getConnection(SERVIDOR+BASE,USUARIO,PASSWORD);
        this.prepararComando(sql, salida, datos);

        ResultSet r = pre.executeQuery();
        hayFilas = r.next();
        
        r.close();
        pre.close();
        con.close();

        return hayFilas;
    }
}
