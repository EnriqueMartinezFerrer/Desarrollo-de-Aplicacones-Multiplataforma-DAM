package modelos;
public class Modelo {
    //<editor-fold defaultstate="collapsed" desc="metodos get y set">  
    //</editor-fold>
}
