package controladores;

import modelos.Modelo;
import vistas.Vista;

public class Controlador {
    private Modelo m;
    private Vista v;
    
    public Controlador(Modelo m, Vista v)
    {
        this.m = m;
        this.v = v;
        
        //Modificaciones de la vista
        
        //Añadir escuchadores
        
        //Acciones
    }
    
    /* MOVER DATOS A LA VISTA */
    
    /* METODOS PRIVADOS */
    
    /* ******************************************************* */
    /* EVENTOS                                                 */
    /* ******************************************************* */
    
}
