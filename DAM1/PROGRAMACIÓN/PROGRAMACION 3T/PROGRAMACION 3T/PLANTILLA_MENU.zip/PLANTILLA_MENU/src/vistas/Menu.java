package vistas;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Menu {
    private JFrame vista;
    
    private final JMenuBar menuBar;
    
    private final JMenu menu1;
    private final JMenuItem elemento1A;

    public Menu()
    {
        //Crear elementos del menu
        menuBar = new JMenuBar();
        menu1 = new JMenu();
        elemento1A = new JMenuItem();
        
        //Propiedades de los JMenuItem y JMenu
        menu1.setText("Menu 1");
        elemento1A.setText("Elemento 1A");
        
        //Reubicar JMenuItem y JMenu
        menu1.add(elemento1A);
        menuBar.add(menu1);
        
        //Eventos de los JMenuItem
        elemento1A.addActionListener(e->{
            vista.dispose();
            vista = Vista.inicio(this);
        });
    }
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Vista.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                Menu m = new Menu();
                m.vista = Vista.inicio(m);
            }
        });
          
    }


    public JMenuItem getFormulario1() {
        return elemento1A;
    }

    public JMenu getFormularios() {
        return menu1;
    }

    public JMenuBar getMenuPrincipal() {
        return menuBar;
    }
}
