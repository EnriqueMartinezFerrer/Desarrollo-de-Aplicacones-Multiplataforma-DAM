#ifndef PGMASK_INTERNAL_H
#define PGMASK_INTERNAL_H

#include "include/pygame_mask.h"
#define PYGAMEAPI_MASK_NUMSLOTS 1

#endif /* ~PGMASK_INTERNAL_H */
