from flask import Flask
from flask import request
from flask import Response
import json
application = Flask(__name__)
mock_data = [
    {
    "id":1,
    "username":"1",
    "email":"",
    "date_birth":"",
    "password":""
    },
    {
    "id":2,
    "username":"1",
    "email":"",
    "date_birth":"",
    "password":""
    },
    {
    "id":3,
    "username":"1",
    "email":"",
    "date_birth":"",
    "password":""
    }
]

credentials = {
    "username":"admin",
    "password":"",
    "dbname":"database-1",
    "host": "database.com"
}

@application.route('/login',methods=['GET','POST'])
def login():
    data = request.get_json()
    #Comprobar usuarios en el login
    for user in mock_data:
        if user['username'] == data['username'] and user['password'] == data['password']:
            print("Aut")
            return 'ok'

    print("No aut")
    return Response('Unauthorized', status=401)
#Hacemos ruta
@application.route('/get-user')
def get_user():
    #query para la ruta 
    id = request.args.get('id')
    id = int(id)
    # Recorremos mock data
    for user in mock_data:
        if user['id'] == id:
            return user
    #Returneamos el error con su status
    print("No encontr")
    return Response('Not found', status=404)
"""application.route('/new-user')
def new_user():
    for user in mock_data:
        if user['username'] == username:
            return Response('Alredy exist', status=405)
        if user['password'] ==
    return"""

    
@application.route('/get-all-users')
def get_all_users():
    mock_data(
        user = credentials["username"],
        password = credentials["password"],
        host = credentials["host"],
        database = credentials["dbname"]
    )
    return mock_data