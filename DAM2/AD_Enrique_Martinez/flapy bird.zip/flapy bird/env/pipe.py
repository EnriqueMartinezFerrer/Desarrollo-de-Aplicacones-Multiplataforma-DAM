import pygame
import os
WIN_WIDHT = 500
WIN_HEIGHT = 100
GAP = 10