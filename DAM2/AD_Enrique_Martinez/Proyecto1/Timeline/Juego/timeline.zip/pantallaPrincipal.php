<!DOCTYPE html>
<html>
<head>
	<title>Pantalla Principal</title>
		<link rel="stylesheet" href="styles.css"/>
		<script src="script.js"></script>
</head>
<body>
<h1 align="center">Arrastra la imagen</h1>

	


<div class="cartaInicio" draggable = "true" id="holaa" ondragstart="drag(event)" id="cartaInicio" >
<?php
	$imgAmerica= 1;
	$imgCampeones= 2;
	$imgIndependencia= 3;
	$imagen= rand (1,3);
	switch ($imagen) {
    case 1:
        echo "<img src = 'descubrimientoAmerica.jpg' draggable = 'true' id='holaa' ondragstart='drag(event)'' id='1492'>";
        break;
    case 2:
         echo "<img src = 'campeones.jpg' draggable = 'true' id='holaa' ondragstart='drag(event)'' id='1492'>";
        break;
    case 3:
         echo "<img src = 'guerraIndependencia.jpg' draggable = 'true' id='holaa' ondragstart='drag(event)'' id='1492'>";
        break;
    }
        ?>
</div>
<br>
<br>
<br>
<br>
<section class = "conjunto">
	<div class="caja" id="0" ondrop="drop(event)" ondragover="allowDrop(event)">
	
	</div>
	<div class="caja" id="1" ondrop="drop(event)" ondragover="allowDrop(event)">
		
	</div>
	<div class="caja" id="2" ondrop="drop(event)" ondragover="allowDrop(event)">
		
	</div>
	<div class="caja" id="3" ondrop="drop(event)" ondragover="allowDrop(event)">
		
	</div>
	<div class="caja" id="4" ondrop="drop(event)" ondragover="allowDrop(event)">
		
	</div>
	<div class="caja" id="5" ondrop="drop(event)" ondragover="allowDrop(event)">
		
	</div>
	<div class="caja" id="6" ondrop="drop(event)" ondragover="allowDrop(event)">
		
	</div>
		<div class="caja" id="6" ondrop="drop(event)" ondragover="allowDrop(event)">
		
	</div>
		<div class="caja" id="6" ondrop="drop(event)" ondragover="allowDrop(event)">
		
	</div>
		<div class="caja" id="6" ondrop="drop(event)" ondragover="allowDrop(event)">
		
	</div>
	
</section>
</body>
</html>