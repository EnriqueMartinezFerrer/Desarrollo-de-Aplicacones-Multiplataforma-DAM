<!DOCTYPE html>
<html>
<head>
	<title>Batalla 1</title>
</head>
<body>
	$numero1 = $_POST["numero1"];
	<?php

	if ($operacion == "sumar") $resultado = $numero1 + $numero2;
?>
</body>
</html>