<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
	<form method="post" action="batalla1.php">
		<input name="numero" placeholder="Número 1" type="number"min="1" max="3"/>
		<button name="operacion" value="sumar">continuar</button>

</body>
</html>