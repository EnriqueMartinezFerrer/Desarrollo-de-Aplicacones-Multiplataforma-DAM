import { Component, OnInit } from '@angular/core';
import { TemarioService } from '../temario.service';
import { Tema } from '../tema';

@Component({
  selector: 'app-primer',
  templateUrl: './primer.component.html',
  styleUrls: ['./primer.component.css']
})
export class PrimerComponent implements OnInit {

  temas: Tema[] = [];
  imagen = '';

  constructor(private temarioService: TemarioService) { }

  ngOnInit(): void {
    this.imagen = this.temarioService.getTemarioDI().imagen_java;
    this.temas = this.temarioService.getTemarioDI().primer_trimestre.map(tema => new Tema(tema.tema, tema.contenido));
  }

}

