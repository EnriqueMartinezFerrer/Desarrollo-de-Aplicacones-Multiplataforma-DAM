import { Component } from '@angular/core';
import { TemarioService } from '../temario.service';
import { Tema } from '../tema';

@Component({
  selector: 'app-di',
  templateUrl: './di.component.html',
  styleUrls: ['./di.component.css']
})
export class DIComponent {
  trimestreSeleccionado = 'primer_trimestre';
  temas: Tema[] = [];
  imagen = '';

  constructor(private temarioService: TemarioService) {}

  cargarTrimestre() {
    const temario = this.temarioService.getTemarioDI();
    this.imagen = temario['imagen_java'];

    if (this.trimestreSeleccionado === 'primer_trimestre') {
      this.temas = temario['primer_trimestre'];
    } else {
      this.temas = temario['segundo_trimestre'];
    }
  }
}
