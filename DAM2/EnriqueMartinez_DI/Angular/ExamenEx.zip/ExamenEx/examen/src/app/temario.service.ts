import { Injectable } from '@angular/core';
import { Tema } from './tema';

@Injectable({
  providedIn: 'root'
})
export class TemarioService {

  private temarioDI = {
    primer_trimestre: [
      new Tema(1, 'Java'),
      new Tema(2, 'JavaFX'),
      new Tema(3, 'Peticiones HTTP')
    ],
    segundo_trimestre: [
      new Tema(1, 'JavaScript'),
      new Tema(2, 'Typescript y Angular'),
      new Tema(3, 'Componentes y directivas'),
      new Tema(4, 'Rutas')
    ],
    imagen_java: 'https://upload.wikimedia.org/wikipedia/en/c/cc/JavaFX_Logo.png',
    imagen_angular: 'https://www.sgart.it/IT/tags/default/file?angular.png'
  };

  private temarioPMDM = {
    primer_trimestre: [
      new Tema(1, 'Kotlin'),
      new Tema(2, 'Android Studio'),
      new Tema(3, 'Componentes'),
      new Tema(4, 'Listas')
    ],
    segundo_trimestre: [
      new Tema(1, 'Fragments'),
      new Tema(2, 'Base datos Firebase')
    ],
    imagen: 'https://e00-elmundo.uecdn.es/assets/multimedia/imagenes/2021/03/23/16164942582533.jpg'
  };

  constructor() { }

  getTemarioDI() {
    return this.temarioDI;
  }

  getTemarioPMDM() {
    return this.temarioPMDM;
  }
}

