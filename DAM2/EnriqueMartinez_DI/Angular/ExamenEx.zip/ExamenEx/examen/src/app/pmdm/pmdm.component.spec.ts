import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PmdmComponent } from './pmdm.component';

describe('PmdmComponent', () => {
  let component: PmdmComponent;
  let fixture: ComponentFixture<PmdmComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PmdmComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PmdmComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});