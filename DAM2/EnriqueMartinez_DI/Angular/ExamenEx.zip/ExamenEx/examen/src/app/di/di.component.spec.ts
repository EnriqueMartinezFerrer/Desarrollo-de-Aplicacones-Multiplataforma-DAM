import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { DIComponent } from './di.component';

describe('DiComponent', () => {
  let component: DIComponent;
  let fixture: ComponentFixture<DIComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [DIComponent]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the default component', () => {
    const titulo = fixture.nativeElement.querySelector('h2');
    expect(titulo.textContent).toContain('Selecciona un trimestre');
  });

  it('should display PrimerComponent when primer radio button is clicked', () => {
    const primerRadio = fixture.nativeElement.querySelector('#primer');
    primerRadio.click();
    fixture.detectChanges();
    const titulo = fixture.nativeElement.querySelector('h2');
    expect(titulo.textContent).toContain('PrimerComponent works');
  });

  it('should display SegundoComponent when segundo radio button is clicked', () => {
    const segundoRadio = fixture.nativeElement.querySelector('#segundo');
    segundoRadio.click();
    fixture.detectChanges();
    const titulo = fixture.nativeElement.querySelector('h2');
    expect(titulo.textContent).toContain('SegundoComponent works');
  });
});
