import { Component, OnInit } from '@angular/core';
import { TemarioService } from '../temario.service';
import { Tema } from '../tema';

@Component({
  selector: 'app-pmdm',
  templateUrl: './pmdm.component.html',
  styleUrls: ['./pmdm.component.css']
})
export class PmdmComponent implements OnInit {

  temas: Tema[] = [];
  imagen = '';

  constructor(private temarioService: TemarioService) { }

  ngOnInit(): void {
    this.imagen = this.temarioService.getTemarioPMDM().imagen;
    this.temas = this.temarioService.getTemarioPMDM().primer_trimestre;
  }

}
