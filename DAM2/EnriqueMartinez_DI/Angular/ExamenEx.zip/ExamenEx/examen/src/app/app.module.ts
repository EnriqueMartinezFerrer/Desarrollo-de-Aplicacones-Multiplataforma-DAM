import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { DIComponent } from './di/di.component';
import { PrimerComponent } from './primer/primer.component';
import { SegundoComponent } from './segundo/segundo.component';
import { PmdmComponent } from './pmdm/pmdm.component';

const routes: Routes = [
  { path: 'di', component: DIComponent },
  { path: 'primer', component: PrimerComponent },
  { path: 'segundo', component: SegundoComponent },
  { path: 'pmdm', component: PmdmComponent },
  { path: '', redirectTo: '/di', pathMatch: 'full' },
];

@NgModule({
  declarations: [
    AppComponent,
    DIComponent,
    PrimerComponent,
    SegundoComponent,
    PmdmComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
