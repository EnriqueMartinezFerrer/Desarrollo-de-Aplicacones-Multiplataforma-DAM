import { Component, OnInit } from '@angular/core';
import { TemarioService } from '../temario.service';
import { Tema } from '../tema';

@Component({
  selector: 'app-segundo',
  templateUrl: './segundo.component.html',
  styleUrls: ['./segundo.component.css']
})
export class SegundoComponent implements OnInit {
  temas: Tema[] = [];
  imagen = '';

  constructor(private temarioService: TemarioService) { }

  ngOnInit() {
    this.imagen = this.temarioService.getTemarioDI().imagen_angular;
    this.temas = this.temarioService.getTemarioDI().segundo_trimestre;
  }
}
