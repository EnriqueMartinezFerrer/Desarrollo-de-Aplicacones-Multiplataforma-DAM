import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PrimerComponent } from './primer.component';
import { TemarioService } from '../temario.service';
import { of } from 'rxjs';

describe('PrimerComponent', () => {
  let component: PrimerComponent;
  let fixture: ComponentFixture<PrimerComponent>;
  let temarioServiceSpy: jasmine.SpyObj<TemarioService>;

  beforeEach(async () => {
    temarioServiceSpy = jasmine.createSpyObj('TemarioService', ['getTemarioDI']);
    await TestBed.configureTestingModule({
      declarations: [PrimerComponent],
      providers: [{ provide: TemarioService, useValue: temarioServiceSpy }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PrimerComponent);
    component = fixture.componentInstance;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load the temario on init', () => {
    const temarioMock = {
      primer_trimestre: [{ tema: 1, contenido: 'Java' }, { tema: 2, contenido: 'JavaFX' }],
      imagen_java: 'https://upload.wikimedia.org/wikipedia/en/c/cc/JavaFX_Logo.png'
    };
    temarioServiceSpy.getTemarioDI.and.returnValue(of(temarioMock));

    component.ngOnInit();

    expect(component.temas.length).toBe(2);
    expect(component.temas[0].tema).toBe(1);
    expect(component.temas[0].contenido).toBe('Java');
    expect(component.temas[1].tema).toBe(2);
    expect(component.temas[1].contenido).toBe('JavaFX');
  });

  it('should render the image and the temario', () => {
    const temarioMock = {
      primer_trimestre: [{ tema: 1, contenido: 'Java' }, { tema: 2, contenido: 'JavaFX' }],
      imagen_java: 'https://upload.wikimedia.org/wikipedia/en/c/cc/JavaFX_Logo.png'
    };
    temarioServiceSpy.getTemarioDI.and.returnValue(of(temarioMock));
    component.ngOnInit();
    fixture.detectChanges();

    const compiled = fixture.nativeElement;
    expect(compiled.querySelector('img').src).toContain(temarioMock.imagen_java);
    expect(compiled.querySelectorAll('li').length).toBe(2);
    expect(compiled.querySelectorAll('li')[0].textContent).toContain(temarioMock.primer_trimestre[0].contenido);
    expect(compiled.querySelectorAll('li')[1].textContent).toContain(temarioMock.primer_trimestre[1].contenido);
  });
});
