export class Tema {
    tema: number;
    contenido: string;
  
    constructor(tema: number, contenido: string) {
      this.tema = tema;
      this.contenido = contenido;
    }
  }
  