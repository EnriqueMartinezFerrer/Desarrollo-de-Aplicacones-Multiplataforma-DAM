let inputNombre=document.getElementById("nombre")
let inputApellido=document.getElementById("apellido")
let aprobare=document.getElementById("aprobado")
let aprobado=false
let div2=document.getElementById("div2")
let boton = document.querySelector("button")
let nombre;
let apellido;
let pasar=false;

aprobare.addEventListener("change",(e)=>{
    if(aprobado){
        aprobado=false
    }
    else{
        aprobado=true
    }
})
inputNombre.addEventListener("change",(e)=>{
    nombre = inputNombre.value
})
inputApellido.addEventListener("change",(e)=>{
    apellido = inputApellido.value
})
boton.addEventListener("click",(e)=>{
    empezar();
})
function empezar(){
    if(nombre==undefined  || apellido==undefined){
        alert("Faltan datos")
    }
    else{
        if(!aprobado){
            div2.innerHTML='<div class="alert alert-warning" role="alert">Así no vamos bien</div>'
        }
        else{
            div2.innerHTML='<div class="alert alert-info" role="alert">Perfecto, estás preparado para empezar</div>'
            setTimeout(() => {
                window.location.href="pag2.html";
            }, 5000);
        }
    }
}