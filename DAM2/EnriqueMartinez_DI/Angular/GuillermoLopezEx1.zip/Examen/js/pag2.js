let urlApi="https://content.guardianapis.com/search?api-key=3206508d-4450-4939-9f05-fd63b56023cd";
let palabra=document.getElementById("palabra")
let size=document.getElementById("size")
let boton1 = document.getElementById("buscarNormal")
let boton2 = document.getElementById("botonCategoria")
let select = document.getElementById("select")
let palabraFiltrar;
let numeroNoticias;
let categoria;
let esNumero = false;
let divCartas = document.getElementById("divCartas")

select.addEventListener("change",(e)=>{
    categoria=select.value
})

palabra.addEventListener("change",(e)=>{
    palabraFiltrar=palabra.value
})
size.addEventListener("change",(e)=>{
    numeroNoticias=size.value
    try {
        numeroNoticias=Number(numeroNoticias)
        esNumero=true
    } catch (error) {
        esNumero=false
    }
})

boton1.addEventListener("click",(e)=>{
    if(numeroNoticias!=undefined || palabraFiltrar!=undefined){
        if(esNumero && numeroNoticias>0){
            fetch(urlApi+`&q=${palabraFiltrar}&page-size=${numeroNoticias}`)
            .then((ok) =>{
                return ok.json();
            })
            .then((ok1)=>{
                divCartas.innerHTML="";
                ok1.response.results.forEach(element => {
                    divCartas.innerHTML+=`<div class="card col-4" style="width: 14rem; margin: 10px">
                    <div class="card-body">
                      <p class="card-text">${element.webTitle}</p>
                      <a href="${element.webUrl}" class="btn btn-primary">Ir a la noticia</a>
                    </div>
                  </div>`
                });
            })
            .catch((err)=>{
                console.log("Ha fallado");
            })
        }
        else{
            alert("Tiene que ser un numero mayor que 0")
        }
    }
    else{
        alert("Tienes que rellenar los campos")
    }
})

boton2.addEventListener("click",(e)=>{
    if(categoria!=null && categoria!=undefined){
        fetch(urlApi+`&section=${categoria}`)
        .then((ok) =>{
            return ok.json();
        })
        .then((ok1)=>{
            divCartas.innerHTML="";
            ok1.response.results.forEach(element => {
                divCartas.innerHTML+=`<div class="card col-4" style="width: 14rem; margin: 10px">
                <div class="card-body">
                  <p class="card-text">${element.webTitle}</p>
                  <a href="${element.webUrl}" class="btn btn-primary">Ir a la noticia</a>
                </div>
              </div>`
            });
        })
        .catch((err)=>{
            console.log("Ha fallado");
        }) 
    }
    else{
        alert("Selecciona una categoría")
    }
})
