package com.example.t2_inicio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class IMCActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_imc)
    }
}