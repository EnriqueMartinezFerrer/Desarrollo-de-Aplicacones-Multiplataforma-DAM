package Clases.src.main.kotlin.model;

public final class Autonomo extends Trabajador {

    private int cuotaSS,

}
