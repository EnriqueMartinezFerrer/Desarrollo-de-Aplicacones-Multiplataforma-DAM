package model

data class Propietario (var nombre: String, var apellido: String, var dni: String)