package Clases.src.main.kotlin.model;

public class MainTrabajadores {

    public static void main(String[] args) {


        Autonomo autonomo = new Autonomo("Autono1","Apellido1","1234A",1234,1000,10000);
        Asalariado asalariado = new Asalariado("Asalariado1","Apellido2","2345A",2345,15,600,300)
    }

}
